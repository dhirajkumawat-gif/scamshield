"""Scoring tests: nine official examples + edge cases (spec section 15)."""
import pytest

from app.feedback import clear_feedback, list_feedback, record_feedback
from app.sample_data import MESSAGE_SAMPLES, TRANSACTION_SAMPLES
from app.scoring import (
    SAFETY_STATEMENT,
    ScoringInputError,
    analyze_message,
    analyze_transaction,
    classify_risk,
    evaluate_sample_dataset,
)


def msg(sample_id):
    return next(s for s in MESSAGE_SAMPLES if s["id"] == sample_id)


def ids(result):
    return [s["id"] for s in result["signals"]]


# --- official examples (tests 1-9) ---------------------------------------
def test_official_messages():
    for sample in MESSAGE_SAMPLES:
        result = analyze_message(sample["text"])
        assert result["score"] == sample["expected_score"], sample["id"]
        assert result["level"] == sample["expected_level"], sample["id"]
        assert sorted(ids(result)) == sorted(sample["expected_signals"]), sample["id"]


def test_m2_breakdown_85():
    result = analyze_message(msg("M2")["text"])
    assert result["score"] == 85 and result["level"] == "HIGH"
    assert result["breakdown"][-1] == "Total: 85/100 — HIGH"


def test_official_transactions():
    for sample in TRANSACTION_SAMPLES:
        result = analyze_transaction(sample["amount"], sample["baseline"], sample["new_device"])
        assert result["score"] == sample["expected_score"], sample["id"]
        assert result["level"] == sample["expected_level"], sample["id"]
        assert sorted(ids(result)) == sorted(sample["expected_signals"]), sample["id"]


# --- message edge cases (10-14) ------------------------------------------
def test_empty_message_rejected():
    with pytest.raises(ScoringInputError):
        analyze_message("")


def test_whitespace_message_rejected():
    with pytest.raises(ScoringInputError):
        analyze_message("   \n\t  ")


def test_too_long_message_rejected():
    with pytest.raises(ScoringInputError):
        analyze_message("a" * 5001)


def test_otp_mention_is_not_a_request():
    for text in (
        "Your OTP is 123456. Never share your OTP with anyone.",
        "We will never ask you to share your PIN or password.",
        "Do not share your one-time code with anyone.",
    ):
        assert "credential_request" not in ids(analyze_message(text)), text


def test_otp_request_triggers_credential_signal():
    for text in ("Please share your OTP to continue.", "Send your card details now", "Reply with your PIN"):
        assert "credential_request" in ids(analyze_message(text)), text


def test_urgency_words_do_not_stack():
    result = analyze_message("URGENT! Act now immediately, your account will be frozen.")
    assert ids(result).count("urgency") == 1
    assert result["score"] == 25


def test_topic_words_alone_do_not_raise_risk():
    for text in ("Your parcel has shipped.", "Your bill is ready.", "Your OTP is 555555."):
        assert analyze_message(text)["score"] == 0, text


def test_plain_link_without_context_is_not_flagged():
    assert analyze_message("Photos from the trip: https://photos.example.org/album/12")["score"] == 0


def test_no_message_text_in_result():
    text = "URGENT! Share your OTP at http://bank-verify.example.test"
    assert text not in str(analyze_message(text))


# --- transaction edge cases (15-20) --------------------------------------
def test_zero_baseline_rejected():
    with pytest.raises(ScoringInputError):
        analyze_transaction(100, 0, False)


def test_negative_baseline_rejected():
    with pytest.raises(ScoringInputError):
        analyze_transaction(100, -5, False)


def test_negative_amount_rejected():
    with pytest.raises(ScoringInputError):
        analyze_transaction(-1, 500, False)


def test_invalid_numbers_rejected():
    for bad in (float("nan"), float("inf"), "abc", None, True):
        with pytest.raises(ScoringInputError):
            analyze_transaction(bad, 500, False)


def test_tier_boundaries_exact():
    assert analyze_transaction(750, 500, False)["score"] == 10      # exactly 1.5x
    assert analyze_transaction(749, 500, False)["score"] == 0       # just below 1.5x
    assert analyze_transaction(1500, 500, False)["score"] == 30     # exactly 3x
    assert analyze_transaction(1499, 500, False)["score"] == 10
    assert analyze_transaction(5000, 500, False)["score"] == 50     # exactly 10x
    assert analyze_transaction(4999, 500, False)["score"] == 30


def test_only_highest_amount_tier_counts():
    result = analyze_transaction(10000, 500, False)
    assert ids(result) == ["amount_10x"] and result["score"] == 50


def test_new_device_only_is_25():
    result = analyze_transaction(500, 500, True)
    assert result["score"] == 25 and result["level"] == "MEDIUM" and ids(result) == ["new_device"]


def test_zero_amount_is_safe():
    result = analyze_transaction(0, 500, False)
    assert result["score"] == 0 and result["transaction"]["ratio"] == 0


# --- bands, cap, feedback (21-23) ----------------------------------------
def test_risk_boundaries():
    assert classify_risk(0) == "LOW"
    assert classify_risk(24) == "LOW"
    assert classify_risk(25) == "MEDIUM"
    assert classify_risk(49) == "MEDIUM"
    assert classify_risk(50) == "HIGH"
    assert classify_risk(100) == "HIGH"


def test_score_capped_at_100():
    text = "URGENT! Share your OTP at http://verify-kyc.example.test. Pay a processing fee to claim your prize."
    result = analyze_message(text)
    assert result["raw_score"] == 135
    assert result["score"] == 100


def test_every_result_has_safety_statement_and_steps():
    for result in (analyze_message(msg("M1")["text"]), analyze_message(msg("M2")["text"]), analyze_transaction(3000, 700, False)):
        assert result["safety_statement"] == SAFETY_STATEMENT == "A risk flag is not proof of fraud."
        assert result["recommendations"]


def test_feedback_recorded_and_listed():
    clear_feedback()
    record = record_feedback("message", "useful", sample_id="M2", comment="clear", score=85, level="HIGH")
    record_feedback("transaction", "not_useful")
    records = list_feedback()
    assert len(records) == 2
    assert records[0]["id"] == record["id"] and records[0]["choice"] == "useful"
    assert records[1]["choice"] == "not_useful"
    assert clear_feedback() == 2 and list_feedback() == []


def test_feedback_rejects_bad_choice():
    with pytest.raises(ValueError):
        record_feedback("message", "maybe")


def test_evaluation_all_nine_pass():
    summary = evaluate_sample_dataset()["summary"]
    assert summary["total"] == 9 and summary["passed"] == 9 and summary["failed"] == 0
    assert summary["false_alarms"] == 0 and summary["missed_high"] == 0
