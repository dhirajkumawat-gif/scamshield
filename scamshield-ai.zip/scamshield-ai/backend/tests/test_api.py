"""API tests (need `pip install -r requirements-dev.txt`, which includes httpx)."""
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health():
    assert client.get("/api/health").json()["status"] == "ok"


def test_samples():
    data = client.get("/api/samples").json()
    assert len(data["messages"]) == 6 and len(data["transactions"]) == 3


def test_analyze_message_m2():
    r = client.post("/api/analyze/message", json={"message": "URGENT! Your bank account will be blocked. Share your OTP at http://bank-verify.example.test", "sample_id": "M2"})
    assert r.status_code == 200
    body = r.json()
    assert body["score"] == 85 and body["level"] == "HIGH" and body["sample_id"] == "M2"
    assert body["safety_statement"] == "A risk flag is not proof of fraud."


def test_analyze_transaction_x2():
    r = client.post("/api/analyze/transaction", json={"amount": 48000, "baseline": 700, "new_device": True})
    assert r.status_code == 200 and r.json()["score"] == 75


def test_empty_message_gives_helpful_error():
    r = client.post("/api/analyze/message", json={"message": "   "})
    assert r.status_code == 422 and "paste a message" in r.json()["detail"]


def test_zero_baseline_gives_helpful_error():
    r = client.post("/api/analyze/transaction", json={"amount": 10, "baseline": 0})
    assert r.status_code == 422 and "greater than zero" in r.json()["detail"]


def test_invalid_payload_does_not_crash_or_echo_input():
    r = client.post("/api/analyze/transaction", json={"amount": "secret-text", "baseline": 5})
    assert r.status_code == 422
    assert "secret-text" not in r.text


def test_evaluation_endpoint():
    body = client.get("/api/evaluation").json()
    assert body["summary"]["passed"] == 9


def test_feedback_roundtrip():
    client.delete("/api/feedback")
    r = client.post("/api/feedback", json={"category": "message", "choice": "useful", "sample_id": "M2"})
    assert r.status_code == 200
    r = client.post("/api/feedback", json={"category": "transaction", "choice": "not_useful"})
    assert r.status_code == 200
    records = client.get("/api/feedback").json()["records"]
    assert [x["choice"] for x in records] == ["useful", "not_useful"]
    assert client.delete("/api/feedback").json()["cleared"] == 2


def test_feedback_invalid_choice_rejected():
    r = client.post("/api/feedback", json={"category": "message", "choice": "maybe"})
    assert r.status_code == 422
