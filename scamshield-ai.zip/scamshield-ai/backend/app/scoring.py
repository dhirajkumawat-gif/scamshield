"""Transparent, deterministic rule-based scoring for H05.

Nothing here makes network calls, visits URLs, or stores/logs user input.
All functions are pure so they can be unit-tested independently of the UI.
"""
from __future__ import annotations

import math
import re
from decimal import Decimal, InvalidOperation
from typing import Any, Optional

from .sample_data import MESSAGE_SAMPLES, TRANSACTION_SAMPLES

MAX_MESSAGE_LENGTH = 5000
MAX_AMOUNT = 1_000_000_000_000  # sanity limit for synthetic INR values
SAFETY_STATEMENT = "A risk flag is not proof of fraud."

# ---------------------------------------------------------------- points ---
POINTS_URGENCY = 25
POINTS_CREDENTIAL = 35
POINTS_URL = 25
POINTS_ADVANCE_FEE = 50
POINTS_NEW_DEVICE = 25
AMOUNT_TIERS = (  # (signal id, label, points) - only the highest applies
    ("amount_10x", "Amount at least 10 times baseline", 50),
    ("amount_3x", "Amount at least 3 times baseline", 30),
    ("amount_1_5x", "Amount at least 1.5 times baseline", 10),
)


class ScoringInputError(ValueError):
    """Raised when user input is invalid. The message is safe to show to users."""


# ------------------------------------------------------------ risk bands ---
def classify_risk(score: int) -> str:
    """LOW 0-24, MEDIUM 25-49, HIGH 50+."""
    if score >= 50:
        return "HIGH"
    if score >= 25:
        return "MEDIUM"
    return "LOW"


def _signal(
    signal_id: str,
    label: str,
    points: int,
    explanation: str,
    evidence: Optional[str] = None,
) -> dict[str, Any]:
    return {
        "id": signal_id,
        "label": label,
        "points": points,
        "explanation": explanation,
        "evidence": evidence,
    }


def _short(text: str, limit: int = 60) -> str:
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


# ----------------------------------------------------- message detectors ---
_URGENCY_RE = re.compile(
    r"\burgent(?:ly)?\b"
    r"|\bact\s+now\b"
    r"|\bimmediately\b"
    r"|\bright\s+away\b"
    r"|\b(?:final|last)\s+(?:warning|notice)\b"
    r"|\b(?:will|shall|may|to)\s+be\s+(?:blocked|frozen|suspended|deactivated|locked|terminated)\b"
    r"|\b(?:account|wallet|card|sim)\s+(?:is\s+|has\s+been\s+)?(?:blocked|frozen|suspended|deactivated|locked)\b"
    r"|\bfrozen\b",
    re.IGNORECASE,
)

_SENSITIVE = (
    r"(?:otp"
    r"|one[\s-]?time\s+(?:code|password|pin|passcode)"
    r"|pin"
    r"|password"
    r"|passcode"
    r"|cvv|cvc"
    r"|security\s+code"
    r"|card\s+(?:number|details)"
    r"|bank(?:ing)?\s+(?:details|password|login|credentials)"
    r"|account\s+(?:number|password)"
    r"|net\s*banking\s+(?:password|details|login)"
    r"|login\s+(?:details|credentials)"
    r"|credentials)"
)
_REQUEST_VERBS = (
    r"(?:share|send|provide|enter|give|tell|submit|disclose|forward|reveal"
    r"|confirm|verify|type|reply\s+with|read\s+out)"
)
# A request = request verb, up to 4 filler words, then a sensitive item.
_CREDENTIAL_RE = re.compile(
    rf"\b{_REQUEST_VERBS}\b(?:\s+[\w'’-]+){{0,4}}?\s+{_SENSITIVE}\b",
    re.IGNORECASE,
)
_NEGATION_RE = re.compile(
    r"\b(?:do\s*not|don['’]?t|never|won['’]?t|will\s+not|should\s+not|shouldn['’]?t|must\s+not|cannot|can['’]?t|not)\b",
    re.IGNORECASE,
)

_URL_RE = re.compile(
    r"(?:https?://|www\.)[^\s<>\"']+"
    r"|\b[a-z0-9][a-z0-9-]*(?:\.[a-z0-9-]+)*\."
    r"(?:com|net|org|in|co|info|xyz|top|link|click|online|site|test|cc|ly)\b(?:/[^\s<>\"']*)?",
    re.IGNORECASE,
)
_HOST_WORD_RE = re.compile(
    r"verify|verification|update|kyc|secure|security|login|signin|account|support"
    r"|bank|wallet|refund|claim|reward|prize",
    re.IGNORECASE,
)
_URL_CONTEXT_RE = re.compile(
    r"\b(?:verify|verification|update|kyc|log\s?in|sign\s?in|account|security|confirm"
    r"|reactivate|unlock|suspend(?:ed)?|blocked|frozen|expired)\b",
    re.IGNORECASE,
)
_IP_HOST_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")
_SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "rb.gy", "shorturl.at"}

_FEE_RE = re.compile(
    r"\b(?:pay|send|deposit|transfer|remit)\b(?:\W+\w+){0,4}?\W+(?:fee|fees|charge|charges|tax|deposit)\b",
    re.IGNORECASE,
)
_PRIZE_RE = re.compile(
    r"\b(?:won|win|winner|prize|lottery|reward|gift|claim|jackpot|lucky\s+draw|inheritance)\b",
    re.IGNORECASE,
)


def _is_negated(text: str, start: int) -> bool:
    """True if a negation ('do not', 'never', ...) sits just before the match in the same sentence."""
    segment = re.split(r"[.!?;\n]", text[:start])[-1][-40:]
    return bool(_NEGATION_RE.search(segment))


def _host_of(url: str) -> str:
    host = re.sub(r"^[a-z]+://", "", url, flags=re.IGNORECASE)
    host = host.split("/")[0].split("?")[0].split("#")[0]
    host = host.split("@")[-1].split(":")[0]
    return host.lower()


def _detect_urgency(text: str) -> Optional[dict[str, Any]]:
    match = _URGENCY_RE.search(text)
    if not match:
        return None
    return _signal(
        "urgency",
        "Urgency or threat",
        POINTS_URGENCY,
        "The message pressures you to act quickly or threatens a consequence "
        "(for example a blocked or frozen account). Scammers use pressure to stop you from checking.",
        _short(match.group(0)),
    )


def _detect_credential_request(text: str) -> Optional[dict[str, Any]]:
    for match in _CREDENTIAL_RE.finditer(text):
        if _is_negated(text, match.start()):
            continue  # e.g. "Do not share your OTP" is a warning, not a request
        return _signal(
            "credential_request",
            "Request for sensitive credentials",
            POINTS_CREDENTIAL,
            "The message asks you to share, send or enter a sensitive item (such as an OTP, PIN, "
            "password or card detail). Genuine organisations do not ask for these by message.",
            _short(match.group(0)),
        )
    return None


def _detect_suspicious_url(text: str) -> Optional[dict[str, Any]]:
    # The link is only analysed as text. It is never opened or fetched.
    for match in _URL_RE.finditer(text):
        url = match.group(0).rstrip(".,;:!?)]}'\"")
        host = _host_of(url)
        reasons: list[str] = []
        if _IP_HOST_RE.match(host):
            reasons.append("uses a raw IP address instead of a domain name")
        if host in _SHORTENERS:
            reasons.append("uses a link shortener that hides the real destination")
        if "xn--" in host:
            reasons.append("uses an encoded look-alike (punycode) domain")
        if "@" in re.sub(r"^[a-z]+://", "", url, flags=re.IGNORECASE).split("/")[0]:
            reasons.append("hides the real host behind an '@' sign")
        word = _HOST_WORD_RE.search(host)
        if word:
            reasons.append(f"the domain contains '{word.group(0).lower()}', a common look-alike word")
        context = _URL_CONTEXT_RE.search(text)
        if context and not reasons:
            reasons.append(
                f"the link appears next to verification or account-threat wording ('{context.group(0).lower()}')"
            )
        if reasons:
            return _signal(
                "suspicious_url",
                "Suspicious link pattern",
                POINTS_URL,
                "A link in the message matches a suspicious pattern: " + "; ".join(reasons) + ". "
                "The link was not opened. A link alone is not evidence of fraud.",
                _short(url),
            )
    return None


def _detect_advance_fee(text: str) -> Optional[dict[str, Any]]:
    fee = _FEE_RE.search(text)
    if fee and _PRIZE_RE.search(text):
        return _signal(
            "advance_fee",
            "Advance-fee or prize pattern",
            POINTS_ADVANCE_FEE,
            "The message matches an advance-fee pattern: it mentions a prize or benefit and asks for "
            "an upfront payment to receive it. This describes a wording pattern only and does not "
            "assert that anyone is guilty of a crime.",
            _short(fee.group(0)),
        )
    return None


def _finish(
    category: str,
    signals: list[dict[str, Any]],
    transaction: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    raw_score = sum(s["points"] for s in signals)
    score = min(100, raw_score)
    level = classify_risk(score)
    breakdown = [f"{s['label']}: +{s['points']}" for s in signals]
    breakdown.append(f"Total: {score}/100 — {level}")
    if raw_score > 100:
        breakdown.append(f"(Raw total {raw_score} is capped at 100.)")
    result: dict[str, Any] = {
        "category": category,
        "score": score,
        "raw_score": raw_score,
        "level": level,
        "signals": signals,
        "breakdown": breakdown,
        "transaction": transaction,
        "safety_statement": SAFETY_STATEMENT,
    }
    result["recommendations"] = get_safe_recommendations(result)
    return result


def analyze_message(message: str) -> dict[str, Any]:
    """Score a pasted message. The message text is never stored, logged or returned."""
    if not isinstance(message, str) or not message.strip():
        raise ScoringInputError("Please paste a message to analyze.")
    if len(message) > MAX_MESSAGE_LENGTH:
        raise ScoringInputError(f"The message is too long. Please keep it under {MAX_MESSAGE_LENGTH:,} characters.")
    detectors = (_detect_urgency, _detect_credential_request, _detect_suspicious_url, _detect_advance_fee)
    signals = [s for s in (d(message) for d in detectors) if s is not None]
    return _finish("message", signals)


# ------------------------------------------------------------ transactions ---
def _to_decimal(value: Any, name: str) -> Decimal:
    if isinstance(value, bool) or not isinstance(value, (int, float, str, Decimal)):
        raise ScoringInputError(f"{name} must be a number.")
    try:
        number = Decimal(str(value).strip())
    except (InvalidOperation, ValueError):
        raise ScoringInputError(f"{name} must be a valid number.") from None
    if not number.is_finite():
        raise ScoringInputError(f"{name} must be a valid number.")
    return number


def analyze_transaction(amount: Any, baseline: Any, new_device: bool = False) -> dict[str, Any]:
    """Score a synthetic transaction against a fictional baseline (INR)."""
    amt = _to_decimal(amount, "Transaction amount")
    base = _to_decimal(baseline, "Baseline")
    if amt < 0:
        raise ScoringInputError("Transaction amount cannot be negative.")
    if base <= 0:
        raise ScoringInputError("Baseline must be greater than zero.")
    if amt > MAX_AMOUNT or base > MAX_AMOUNT:
        raise ScoringInputError("Amounts are too large for this demo.")

    ratio = amt / base  # unrounded ratio is used for classification
    signals: list[dict[str, Any]] = []
    tier: Optional[tuple[str, str, int]] = None
    if amt >= base * 10:
        tier = AMOUNT_TIERS[0]
    elif amt >= base * 3:
        tier = AMOUNT_TIERS[1]
    elif amt * 2 >= base * 3:  # amt >= 1.5 * base, exact (no float rounding)
        tier = AMOUNT_TIERS[2]
    if tier:
        signal_id, label, points = tier
        signals.append(
            _signal(
                signal_id,
                label,
                points,
                f"The amount is {float(ratio):.2f}x the fictional usual baseline. "
                "Only the highest applicable amount tier is counted.",
                f"{float(ratio):.2f}x baseline",
            )
        )
    if bool(new_device):
        signals.append(
            _signal(
                "new_device",
                "New device",
                POINTS_NEW_DEVICE,
                "The transaction came from a device not seen before for this user. "
                "This can be innocent (a new phone) but is worth confirming.",
                "new device",
            )
        )
    details = {
        "amount": float(amt),
        "baseline": float(base),
        "ratio": round(float(ratio), 2),
        "ratio_display": f"{float(ratio):.2f}x",
        "new_device": bool(new_device),
    }
    return _finish("transaction", signals, details)


# --------------------------------------------------------- recommendations ---
def get_safe_recommendations(result: dict[str, Any]) -> list[str]:
    level = result.get("level", "LOW")
    category = result.get("category", "message")
    ids = {s["id"] for s in result.get("signals", [])}
    tips: list[str] = []

    if category == "message":
        if level == "HIGH":
            tips += [
                "Do not click any link or reply with sensitive information.",
                "Open the official app, or type the organization's known website address yourself.",
                "Contact the organization through a known official channel, not the details in this message.",
                "If you already shared sensitive information, contact your bank or service provider "
                "through its official channel as soon as possible.",
            ]
        elif level == "MEDIUM":
            tips += [
                "Pause before acting on this message.",
                "Verify the request independently using the official app or website.",
                "Avoid using phone numbers or links supplied only in this message.",
            ]
        else:
            tips += [
                "No listed risk signal was detected in this message.",
                "This is not a guarantee of safety. Rules only cover a few known patterns.",
                "If you are still unsure, verify independently through the official app or website.",
            ]
        if "credential_request" in ids:
            tips.append("Never share OTPs, PINs, passwords or card security codes, even with someone claiming to be your bank.")
    else:
        if level == "LOW":
            tips.append("No listed risk signal was detected for this synthetic transaction. This is not a guarantee of safety.")
        else:
            tips.append("Review whether this amount and device match what you expect.")
        tips += [
            "If you do not recognize the transaction, contact your bank through its official app or a known official phone number.",
            "Never share OTPs, PINs, passwords or card security codes.",
            "This tool does not block, reverse or investigate transactions. Only your bank can do that.",
        ]
    return tips


# ------------------------------------------------------------- evaluation ---
def evaluate_sample_dataset() -> dict[str, Any]:
    """Run all nine supplied examples through the real scoring functions."""
    rows: list[dict[str, Any]] = []
    for sample in MESSAGE_SAMPLES:
        rows.append(_evaluate_one(sample, "message", analyze_message(sample["text"])))
    for sample in TRANSACTION_SAMPLES:
        result = analyze_transaction(sample["amount"], sample["baseline"], sample["new_device"])
        rows.append(_evaluate_one(sample, "transaction", result))

    total = len(rows)
    passed = sum(1 for r in rows if r["passed"])
    expected_counts = {lvl: sum(1 for r in rows if r["expected_level"] == lvl) for lvl in ("LOW", "MEDIUM", "HIGH")}
    false_alarms = sum(1 for r in rows if r["expected_level"] == "LOW" and r["observed_level"] != "LOW")
    missed_high = sum(1 for r in rows if r["expected_level"] == "HIGH" and r["observed_level"] != "HIGH")
    tp = sum(1 for r in rows if r["expected_level"] == "HIGH" and r["observed_level"] == "HIGH")
    fp = sum(1 for r in rows if r["expected_level"] != "HIGH" and r["observed_level"] == "HIGH")
    fn = missed_high
    summary = {
        "total": total,
        "passed": passed,
        "failed": total - passed,
        "pass_rate": round(100 * passed / total, 1) if total else 0.0,
        "expected_counts": expected_counts,
        "score_matches": sum(1 for r in rows if r["expected_score"] == r["observed_score"]),
        "level_matches": sum(1 for r in rows if r["expected_level"] == r["observed_level"]),
        "false_alarms": false_alarms,
        "missed_high": missed_high,
        "high_precision": round(tp / (tp + fp), 2) if (tp + fp) else None,
        "high_recall": round(tp / (tp + fn), 2) if (tp + fn) else None,
        "note": (
            "Exercise-set evaluation counts on 9 synthetic examples. These are not validated "
            "real-world precision, recall or accuracy."
        ),
    }
    return {"rows": rows, "summary": summary}


def _evaluate_one(sample: dict[str, Any], category: str, result: dict[str, Any]) -> dict[str, Any]:
    observed_ids = [s["id"] for s in result["signals"]]
    problems: list[str] = []
    if result["score"] != sample["expected_score"]:
        problems.append(f"score {result['score']} != expected {sample['expected_score']}")
    if result["level"] != sample["expected_level"]:
        problems.append(f"level {result['level']} != expected {sample['expected_level']}")
    if sorted(observed_ids) != sorted(sample["expected_signals"]):
        problems.append(f"signals {observed_ids} != expected {sample['expected_signals']}")
    return {
        "test_id": sample["id"],
        "category": category,
        "expected_score": sample["expected_score"],
        "observed_score": result["score"],
        "expected_level": sample["expected_level"],
        "observed_level": result["level"],
        "observed_signals": observed_ids,
        "passed": not problems,
        "explanation": "Matches expected result." if not problems else "; ".join(problems),
    }
