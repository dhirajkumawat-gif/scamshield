"""Synthetic starter data for H05 (Sobhasaria Hackfest 2026).

All records are fictional exercise examples. The labels are exercise labels,
not universal truth about any real message or transaction.
"""
from __future__ import annotations

from typing import Any

MESSAGE_SAMPLES: list[dict[str, Any]] = [
    {
        "id": "M1",
        "text": "Your parcel is delayed. Check tracking in the official app.",
        "expected_level": "LOW",
        "expected_score": 0,
        "expected_signals": [],
    },
    {
        "id": "M2",
        "text": "URGENT! Your bank account will be blocked. Share your OTP at http://bank-verify.example.test",
        "expected_level": "HIGH",
        "expected_score": 85,
        "expected_signals": ["urgency", "credential_request", "suspicious_url"],
    },
    {
        "id": "M3",
        "text": "You won a prize. Pay a processing fee now to claim it.",
        "expected_level": "HIGH",
        "expected_score": 50,
        "expected_signals": ["advance_fee"],
    },
    {
        "id": "M4",
        "text": "Your electricity bill is available in the official provider app.",
        "expected_level": "LOW",
        "expected_score": 0,
        "expected_signals": [],
    },
    {
        "id": "M5",
        "text": "483921 is your one-time code for login. Do not share it with anyone.",
        "expected_level": "LOW",
        "expected_score": 0,
        "expected_signals": [],
    },
    {
        "id": "M6",
        "text": (
            "Dear customer, your KYC has expired. Update immediately at "
            "http://kyc-update.example.test or your wallet will be frozen."
        ),
        "expected_level": "HIGH",
        "expected_score": 50,
        "expected_signals": ["urgency", "suspicious_url"],
    },
]

TRANSACTION_SAMPLES: list[dict[str, Any]] = [
    {
        "id": "X1",
        "amount": 450,
        "baseline": 500,
        "new_device": False,
        "expected_level": "LOW",
        "expected_score": 0,
        "expected_signals": [],
    },
    {
        "id": "X2",
        "amount": 48000,
        "baseline": 700,
        "new_device": True,
        "expected_level": "HIGH",
        "expected_score": 75,
        "expected_signals": ["amount_10x", "new_device"],
    },
    {
        "id": "X3",
        "amount": 3000,
        "baseline": 700,
        "new_device": False,
        "expected_level": "MEDIUM",
        "expected_score": 30,
        "expected_signals": ["amount_3x"],
    },
]
