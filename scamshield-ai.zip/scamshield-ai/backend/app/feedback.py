"""In-memory feedback store.

Feedback lives only in this process's memory: it disappears when the server restarts.
Original message text and transaction inputs are never stored here.
"""
from __future__ import annotations

import threading
from datetime import datetime, timezone
from typing import Any, Optional

MAX_RECORDS = 500
_lock = threading.Lock()
_records: list[dict[str, Any]] = []
_counter = 0


def record_feedback(
    category: str,
    choice: str,
    sample_id: Optional[str] = None,
    comment: Optional[str] = None,
    score: Optional[int] = None,
    level: Optional[str] = None,
) -> dict[str, Any]:
    global _counter
    if category not in ("message", "transaction"):
        raise ValueError("Unknown analysis category.")
    if choice not in ("useful", "not_useful"):
        raise ValueError("Feedback must be 'useful' or 'not_useful'.")
    cleaned = (comment or "").strip()[:200] or None
    with _lock:
        _counter += 1
        record = {
            "id": f"F{_counter:03d}",
            "sample_id": sample_id,
            "category": category,
            "choice": choice,
            "comment": cleaned,
            "score": score,
            "level": level,
            "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        }
        _records.append(record)
        del _records[:-MAX_RECORDS]
        return dict(record)


def list_feedback() -> list[dict[str, Any]]:
    with _lock:
        return [dict(r) for r in _records]


def clear_feedback() -> int:
    global _counter
    with _lock:
        count = len(_records)
        _records.clear()
        _counter = 0
        return count
