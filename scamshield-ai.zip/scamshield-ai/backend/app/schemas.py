"""Pydantic request schemas. Detailed range checks live in scoring.py so errors stay friendly."""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field


class MessageRequest(BaseModel):
    message: str
    sample_id: Optional[str] = Field(default=None, max_length=10)


class TransactionRequest(BaseModel):
    amount: float
    baseline: float
    new_device: bool = False
    sample_id: Optional[str] = Field(default=None, max_length=10)


class FeedbackRequest(BaseModel):
    category: Literal["message", "transaction"]
    choice: Literal["useful", "not_useful"]
    sample_id: Optional[str] = Field(default=None, max_length=10)
    comment: Optional[str] = Field(default=None, max_length=200)
    score: Optional[int] = Field(default=None, ge=0, le=100)
    level: Optional[Literal["LOW", "MEDIUM", "HIGH"]] = None
