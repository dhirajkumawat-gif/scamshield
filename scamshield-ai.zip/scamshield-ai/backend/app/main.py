"""FastAPI application for ScamShield AI (H05).

Privacy notes: request bodies are never logged or echoed back in errors, and
links inside messages are analysed as text only (never fetched).
"""
from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from . import feedback
from .sample_data import MESSAGE_SAMPLES, TRANSACTION_SAMPLES
from .schemas import FeedbackRequest, MessageRequest, TransactionRequest
from .scoring import (
    ScoringInputError,
    analyze_message,
    analyze_transaction,
    evaluate_sample_dataset,
)

app = FastAPI(title="ScamShield AI", version="1.0.0", description="H05 scam message & transaction risk triage (prototype)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["GET", "POST", "DELETE"],
    allow_headers=["Content-Type"],
)


@app.exception_handler(ScoringInputError)
async def scoring_error_handler(_: Request, exc: ScoringInputError) -> JSONResponse:
    return JSONResponse(status_code=422, content={"detail": str(exc)})


@app.exception_handler(RequestValidationError)
async def validation_error_handler(_: Request, exc: RequestValidationError) -> JSONResponse:
    # Build a friendly message from field names only; never echo the submitted values.
    fields = sorted({str(e["loc"][-1]) for e in exc.errors() if e.get("loc")})
    detail = "Invalid input" + (f" for: {', '.join(fields)}." if fields else ".") + " Please check the values and try again."
    return JSONResponse(status_code=422, content={"detail": detail})


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok", "app": "ScamShield AI", "challenge": "H05"}


@app.get("/api/samples")
def samples() -> dict[str, list]:
    return {"messages": MESSAGE_SAMPLES, "transactions": TRANSACTION_SAMPLES}


@app.post("/api/analyze/message")
def post_analyze_message(body: MessageRequest) -> dict:
    result = analyze_message(body.message)
    result["sample_id"] = body.sample_id
    return result


@app.post("/api/analyze/transaction")
def post_analyze_transaction(body: TransactionRequest) -> dict:
    result = analyze_transaction(body.amount, body.baseline, body.new_device)
    result["sample_id"] = body.sample_id
    return result


@app.get("/api/evaluation")
def get_evaluation() -> dict:
    return evaluate_sample_dataset()


@app.post("/api/feedback")
def post_feedback(body: FeedbackRequest) -> dict:
    return feedback.record_feedback(
        category=body.category,
        choice=body.choice,
        sample_id=body.sample_id,
        comment=body.comment,
        score=body.score,
        level=body.level,
    )


@app.get("/api/feedback")
def get_feedback() -> dict:
    return {"records": feedback.list_feedback(), "storage": "in-memory (cleared when the server restarts)"}


@app.delete("/api/feedback")
def delete_feedback() -> dict:
    return {"cleared": feedback.clear_feedback()}


# Serve the production frontend build (frontend/dist) if it exists.
_DIST = Path(__file__).resolve().parents[2] / "frontend" / "dist"
if _DIST.is_dir():
    app.mount("/", StaticFiles(directory=_DIST, html=True), name="frontend")
