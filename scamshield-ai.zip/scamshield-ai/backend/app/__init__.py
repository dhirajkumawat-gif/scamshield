"""ScamShield AI backend package."""
