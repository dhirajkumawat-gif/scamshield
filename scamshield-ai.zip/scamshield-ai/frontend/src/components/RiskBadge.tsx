import { AlertTriangle, ShieldAlert, ShieldCheck } from "lucide-react";
import type { RiskLevel } from "../types";

export const LEVEL_STYLES: Record<RiskLevel, { badge: string; bar: string; text: string; label: string }> = {
  LOW: { badge: "bg-emerald-50 text-emerald-800 border-emerald-300", bar: "bg-emerald-500", text: "text-emerald-700", label: "LOW" },
  MEDIUM: { badge: "bg-amber-50 text-amber-900 border-amber-300", bar: "bg-amber-500", text: "text-amber-700", label: "MEDIUM" },
  HIGH: { badge: "bg-red-50 text-red-800 border-red-300", bar: "bg-red-600", text: "text-red-700", label: "HIGH" },
};

const ICONS = { LOW: ShieldCheck, MEDIUM: AlertTriangle, HIGH: ShieldAlert } as const;

/** Colour is never the only cue: the label, icon and (optional) score are always shown. */
export function RiskBadge({ level, score }: { level: RiskLevel; score?: number }) {
  const Icon = ICONS[level];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-sm font-bold ${LEVEL_STYLES[level].badge}`}>
      <Icon className="h-4 w-4" aria-hidden="true" />
      <span>{level}</span>
      {score !== undefined && <span className="font-semibold">· {score}/100</span>}
    </span>
  );
}
