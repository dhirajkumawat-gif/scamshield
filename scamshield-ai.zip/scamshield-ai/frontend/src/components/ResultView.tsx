import { CheckCircle2, ListChecks } from "lucide-react";
import type { AnalysisResult } from "../types";
import { FeedbackBar } from "./FeedbackBar";
import { RiskBadge } from "./RiskBadge";
import { ScoreBar } from "./ScoreBar";

function inr(n: number) {
  return `₹${n.toLocaleString("en-IN")}`;
}

export function ResultView({ result, showFeedback = true }: { result: AnalysisResult; showFeedback?: boolean }) {
  const tx = result.transaction;
  return (
    <div className="space-y-5" aria-live="polite">
      <div>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Risk score</p>
            <p className="text-4xl font-extrabold text-navy-900">
              {result.score}
              <span className="text-lg font-semibold text-slate-500">/100</span>
            </p>
          </div>
          <RiskBadge level={result.level} score={result.score} />
        </div>
        <div className="mt-3">
          <ScoreBar score={result.score} level={result.level} />
        </div>
      </div>

      {tx && (
        <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            ["Transaction amount", inr(tx.amount)],
            ["Baseline amount", inr(tx.baseline)],
            ["Amount ÷ baseline", tx.ratio_display],
            ["New device", tx.new_device ? "Yes" : "No"],
          ].map(([k, v]) => (
            <div key={k} className="rounded-lg border border-slate-200 bg-slate-50 p-3">
              <dt className="text-xs text-slate-500">{k}</dt>
              <dd className="text-base font-bold text-slate-900">{v}</dd>
            </div>
          ))}
        </dl>
      )}

      <section aria-labelledby="signals-heading">
        <h3 id="signals-heading" className="mb-2 text-sm font-semibold text-slate-800">
          Risk signals detected
        </h3>
        {result.signals.length === 0 ? (
          <p className="flex items-start gap-2 rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-900">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
            No listed risk signal was detected. This is not a guarantee of safety.
          </p>
        ) : (
          <ul className="space-y-2">
            {result.signals.map((s) => (
              <li key={s.id} className="rounded-lg border border-slate-200 p-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-semibold text-slate-900">{s.label}</span>
                  <span className="rounded-md bg-navy-800 px-2 py-0.5 text-xs font-bold text-white">+{s.points}</span>
                </div>
                <p className="mt-1 text-sm text-slate-700">{s.explanation}</p>
                {s.evidence && (
                  <p className="mt-1 text-xs text-slate-500">
                    Matched: <code className="rounded bg-slate-100 px-1 py-0.5">{s.evidence}</code>
                  </p>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>

      <details open className="rounded-lg border border-slate-200 p-3">
        <summary className="cursor-pointer text-sm font-semibold text-slate-800">How the score was calculated</summary>
        <ul className="mt-2 space-y-1 font-mono text-sm text-slate-800">
          {result.breakdown.map((line) => (
            <li key={line}>{line}</li>
          ))}
        </ul>
      </details>

      <section aria-labelledby="steps-heading">
        <h3 id="steps-heading" className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-800">
          <ListChecks className="h-4 w-4" aria-hidden="true" /> Safe next steps
        </h3>
        <ol className="list-decimal space-y-1 pl-5 text-sm text-slate-700">
          {result.recommendations.map((r) => (
            <li key={r}>{r}</li>
          ))}
        </ol>
      </section>

      <p className="rounded-lg bg-navy-900 px-4 py-3 text-sm font-semibold text-white">{result.safety_statement}</p>

      {showFeedback && <FeedbackBar result={result} />}
    </div>
  );
}
