import { useState } from "react";
import { Check, ThumbsDown, ThumbsUp } from "lucide-react";
import { submitFeedback } from "../services/api";
import type { AnalysisResult, Choice } from "../types";
import { ErrorNote } from "./Notices";

export function FeedbackBar({ result }: { result: AnalysisResult }) {
  const [comment, setComment] = useState("");
  const [recorded, setRecorded] = useState<Choice | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function send(choice: Choice) {
    setBusy(true);
    setError(null);
    try {
      await submitFeedback({
        category: result.category,
        choice,
        sample_id: result.sample_id ?? null,
        comment: comment.trim() || null,
        score: result.score,
        level: result.level,
      });
      setRecorded(choice);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not record feedback.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section aria-labelledby="feedback-heading" className="rounded-xl border border-slate-200 bg-slate-50 p-4">
      <h3 id="feedback-heading" className="text-sm font-semibold text-slate-800">
        Was this result useful?
      </h3>
      {recorded ? (
        <p role="status" className="mt-2 flex items-center gap-2 text-sm font-medium text-emerald-700">
          <Check className="h-4 w-4" aria-hidden="true" />
          Feedback recorded: {recorded === "useful" ? "Useful" : "Not useful"}. (Stored in memory only.)
        </p>
      ) : (
        <>
          <label htmlFor="fb-comment" className="mt-2 block text-xs text-slate-600">
            Optional short comment (do not include personal or sensitive details)
          </label>
          <input
            id="fb-comment"
            className="input mt-1"
            maxLength={200}
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="e.g. The explanation was clear"
          />
          <div className="mt-3 flex flex-wrap gap-2">
            <button type="button" className="btn-secondary" disabled={busy} onClick={() => send("useful")}>
              <ThumbsUp className="h-4 w-4" aria-hidden="true" /> Useful
            </button>
            <button type="button" className="btn-secondary" disabled={busy} onClick={() => send("not_useful")}>
              <ThumbsDown className="h-4 w-4" aria-hidden="true" /> Not useful
            </button>
          </div>
        </>
      )}
      {error && <div className="mt-2"><ErrorNote>{error}</ErrorNote></div>}
    </section>
  );
}
