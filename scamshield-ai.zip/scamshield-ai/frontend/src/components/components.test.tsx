import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import { RiskBadge } from "./RiskBadge";
import { ScoreBar } from "./ScoreBar";
import { ResultView } from "./ResultView";
import type { AnalysisResult } from "../types";

const sample: AnalysisResult = {
  category: "message",
  score: 85,
  raw_score: 85,
  level: "HIGH",
  signals: [{ id: "urgency", label: "Urgency or threat", points: 25, explanation: "Pressure wording.", evidence: "URGENT" }],
  breakdown: ["Urgency or threat: +25", "Total: 85/100 — HIGH"],
  recommendations: ["Do not click any link."],
  safety_statement: "A risk flag is not proof of fraud.",
  transaction: null,
  sample_id: "M2",
};

describe("components", () => {
  it("RiskBadge shows the text label and score, not just colour", () => {
    render(<RiskBadge level="HIGH" score={85} />);
    expect(screen.getByText("HIGH")).toBeTruthy();
    expect(screen.getByText("· 85/100")).toBeTruthy();
  });

  it("ScoreBar exposes an accessible progressbar", () => {
    render(<ScoreBar score={30} level="MEDIUM" />);
    const bar = screen.getByRole("progressbar");
    expect(bar.getAttribute("aria-valuenow")).toBe("30");
  });

  it("ResultView shows the exact safety statement, breakdown and feedback buttons", () => {
    render(<ResultView result={sample} />);
    expect(screen.getByText("A risk flag is not proof of fraud.")).toBeTruthy();
    expect(screen.getByText("Total: 85/100 — HIGH")).toBeTruthy();
    expect(screen.getByRole("button", { name: /not useful/i })).toBeTruthy();
    expect(screen.getByRole("button", { name: /^useful$/i })).toBeTruthy();
  });
});
