import type { RiskLevel } from "../types";
import { LEVEL_STYLES } from "./RiskBadge";

export function ScoreBar({ score, level }: { score: number; level: RiskLevel }) {
  return (
    <div>
      <div
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={score}
        aria-label={`Risk score ${score} out of 100, ${level}`}
        className="relative h-3 w-full overflow-hidden rounded-full bg-slate-200"
      >
        <div className={`h-full rounded-full transition-all ${LEVEL_STYLES[level].bar}`} style={{ width: `${score}%` }} />
        {/* band markers at 25 and 50 */}
        <span className="absolute inset-y-0 left-1/4 w-px bg-white/80" aria-hidden="true" />
        <span className="absolute inset-y-0 left-1/2 w-px bg-white/80" aria-hidden="true" />
      </div>
      <div className="mt-1 flex justify-between text-[11px] text-slate-500" aria-hidden="true">
        <span>0</span>
        <span>LOW &lt; 25</span>
        <span>MEDIUM 25–49</span>
        <span>HIGH 50+</span>
      </div>
    </div>
  );
}
