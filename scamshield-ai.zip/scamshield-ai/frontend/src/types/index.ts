export type RiskLevel = "LOW" | "MEDIUM" | "HIGH";
export type Category = "message" | "transaction";
export type Choice = "useful" | "not_useful";

export interface Signal {
  id: string;
  label: string;
  points: number;
  explanation: string;
  evidence?: string | null;
}

export interface TransactionDetails {
  amount: number;
  baseline: number;
  ratio: number;
  ratio_display: string;
  new_device: boolean;
}

export interface AnalysisResult {
  category: Category;
  score: number;
  raw_score: number;
  level: RiskLevel;
  signals: Signal[];
  breakdown: string[];
  recommendations: string[];
  safety_statement: string;
  transaction: TransactionDetails | null;
  sample_id?: string | null;
}

export interface MessageSample {
  id: string;
  text: string;
  expected_level: RiskLevel;
  expected_score: number;
  expected_signals: string[];
}

export interface TransactionSample {
  id: string;
  amount: number;
  baseline: number;
  new_device: boolean;
  expected_level: RiskLevel;
  expected_score: number;
  expected_signals: string[];
}

export interface SamplesResponse {
  messages: MessageSample[];
  transactions: TransactionSample[];
}

export interface EvaluationRow {
  test_id: string;
  category: Category;
  expected_score: number;
  observed_score: number;
  expected_level: RiskLevel;
  observed_level: RiskLevel;
  observed_signals: string[];
  passed: boolean;
  explanation: string;
}

export interface EvaluationSummary {
  total: number;
  passed: number;
  failed: number;
  pass_rate: number;
  expected_counts: Record<RiskLevel, number>;
  score_matches: number;
  level_matches: number;
  false_alarms: number;
  missed_high: number;
  high_precision: number | null;
  high_recall: number | null;
  note: string;
}

export interface EvaluationResponse {
  rows: EvaluationRow[];
  summary: EvaluationSummary;
}

export interface FeedbackRecord {
  id: string;
  sample_id: string | null;
  category: Category;
  choice: Choice;
  comment: string | null;
  score: number | null;
  level: RiskLevel | null;
  created_at: string;
}

export interface HistoryItem {
  id: number;
  category: Category;
  sampleId: string | null;
  score: number;
  level: RiskLevel;
  at: string;
}

export type PageId = "overview" | "message" | "transaction" | "lab" | "evaluation" | "feedback" | "about";
