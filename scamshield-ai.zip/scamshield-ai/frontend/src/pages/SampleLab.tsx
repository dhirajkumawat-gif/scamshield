import { useState } from "react";
import { ArrowRightCircle, Play, PlayCircle, RotateCcw } from "lucide-react";
import { ErrorNote, InfoNote, PageHeader } from "../components/Notices";
import { RiskBadge } from "../components/RiskBadge";
import { analyzeMessage, analyzeTransaction } from "../services/api";
import type { AnalysisResult, MessageSample, TransactionSample } from "../types";

type Sample = (MessageSample & { kind: "message" }) | (TransactionSample & { kind: "transaction" });
type Outcome = { result: AnalysisResult; passed: boolean } | { error: string };

interface Props {
  messages: MessageSample[];
  transactions: TransactionSample[];
  onLoadMessage: (s: MessageSample) => void;
  onLoadTransaction: (s: TransactionSample) => void;
  onAnalyzed: (r: AnalysisResult) => void;
}

export default function SampleLab({ messages, transactions, onLoadMessage, onLoadTransaction, onAnalyzed }: Props) {
  const [outcomes, setOutcomes] = useState<Record<string, Outcome>>({});
  const all: Sample[] = [
    ...messages.map((m) => ({ ...m, kind: "message" as const })),
    ...transactions.map((t) => ({ ...t, kind: "transaction" as const })),
  ];

  async function run(sample: Sample) {
    try {
      const result =
        sample.kind === "message"
          ? await analyzeMessage(sample.text, sample.id)
          : await analyzeTransaction(sample.amount, sample.baseline, sample.new_device, sample.id);
      // PASS/FAIL is computed from the real API result, never hard-coded.
      const passed = result.score === sample.expected_score && result.level === sample.expected_level;
      setOutcomes((o) => ({ ...o, [sample.id]: { result, passed } }));
      onAnalyzed(result);
    } catch (e) {
      setOutcomes((o) => ({ ...o, [sample.id]: { error: e instanceof Error ? e.message : "Analysis failed." } }));
    }
  }

  async function runAll() {
    for (const s of all) await run(s);
  }

  return (
    <div>
      <PageHeader title="Sample Lab" subtitle="Browse the nine synthetic examples, load them into a scanner, or run them and compare expected vs observed." />
      <div className="mb-4 flex flex-wrap gap-2">
        <button type="button" className="btn-primary" onClick={runAll}><PlayCircle className="h-4 w-4" aria-hidden="true" /> Run all 9</button>
        <button type="button" className="btn-secondary" onClick={() => setOutcomes({})}><RotateCcw className="h-4 w-4" aria-hidden="true" /> Reset results</button>
      </div>
      <div className="mb-4"><InfoNote>All records are synthetic exercise examples. Their labels are exercise labels, not universal truth.</InfoNote></div>
      <ul className="space-y-3">
        {all.map((s) => {
          const outcome = outcomes[s.id];
          return (
            <li key={s.id} className="card">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-bold text-navy-900">{s.id} <span className="font-normal text-slate-500">· {s.kind}</span></p>
                  <p className="mt-1 break-words text-sm text-slate-700">
                    {s.kind === "message"
                      ? s.text
                      : `Amount ₹${s.amount.toLocaleString("en-IN")} vs baseline ₹${s.baseline.toLocaleString("en-IN")}, new device: ${s.new_device ? "yes" : "no"}`}
                  </p>
                  <p className="mt-2 flex flex-wrap items-center gap-2 text-xs text-slate-600">
                    Expected: <RiskBadge level={s.expected_level} score={s.expected_score} />
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button type="button" className="btn-secondary" onClick={() => run(s)}><Play className="h-4 w-4" aria-hidden="true" /> Run check</button>
                  <button type="button" className="btn-secondary" onClick={() => (s.kind === "message" ? onLoadMessage(s) : onLoadTransaction(s))}>
                    <ArrowRightCircle className="h-4 w-4" aria-hidden="true" /> Load into scanner
                  </button>
                </div>
              </div>
              {outcome && "error" in outcome && <div className="mt-3"><ErrorNote>{outcome.error}</ErrorNote></div>}
              {outcome && "result" in outcome && (
                <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="text-slate-600">Observed:</span>
                    <RiskBadge level={outcome.result.level} score={outcome.result.score} />
                    <span className={`rounded-md px-2 py-0.5 text-xs font-bold ${outcome.passed ? "bg-emerald-600 text-white" : "bg-red-600 text-white"}`}>
                      {outcome.passed ? "PASS" : "FAIL"}
                    </span>
                  </div>
                  <ul className="mt-2 list-disc pl-5 text-slate-700">
                    {outcome.result.signals.length === 0 ? <li>No listed risk signal detected.</li> : outcome.result.signals.map((sig) => <li key={sig.id}>{sig.label}: +{sig.points}</li>)}
                  </ul>
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
