import { useCallback, useEffect, useState } from "react";
import { RefreshCw } from "lucide-react";
import { ErrorNote, InfoNote, PageHeader } from "../components/Notices";
import { RiskBadge } from "../components/RiskBadge";
import { getEvaluation } from "../services/api";
import type { EvaluationResponse } from "../types";

export default function Evaluation() {
  const [data, setData] = useState<EvaluationResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await getEvaluation());
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not run the evaluation.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const s = data?.summary;
  const cards: [string, string][] = s
    ? [
        ["Total tests", String(s.total)],
        ["Passed", String(s.passed)],
        ["Failed", String(s.failed)],
        ["Observed pass rate", `${s.pass_rate}%`],
        ["False alarms (expected LOW)", String(s.false_alarms)],
        ["Missed expected HIGH", String(s.missed_high)],
      ]
    : [];

  return (
    <div>
      <PageHeader title="Evaluation & Test Results" subtitle="The nine supplied examples are run through the real scoring functions every time this page loads." />
      <div className="mb-4 flex gap-2">
        <button type="button" className="btn-primary" onClick={() => void load()} disabled={loading}>
          <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} aria-hidden="true" /> Re-run evaluation
        </button>
      </div>
      {error && <ErrorNote>{error}</ErrorNote>}
      {s && data && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
            {cards.map(([k, v]) => (
              <div key={k} className="card !p-4">
                <p className="text-xs text-slate-500">{k}</p>
                <p className="text-2xl font-extrabold text-navy-900">{v}</p>
              </div>
            ))}
          </div>
          <div className="card overflow-x-auto !p-0">
            <table className="min-w-full divide-y divide-slate-200">
              <caption className="sr-only">Expected versus observed results for the nine synthetic examples</caption>
              <thead className="bg-slate-50">
                <tr>
                  {["Test", "Category", "Expected score", "Observed score", "Expected level", "Observed level", "Result", "Explanation"].map((h) => (
                    <th key={h} scope="col" className="th">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data.rows.map((r) => (
                  <tr key={r.test_id}>
                    <td className="td font-bold">{r.test_id}</td>
                    <td className="td capitalize">{r.category}</td>
                    <td className="td">{r.expected_score}</td>
                    <td className="td">{r.observed_score}</td>
                    <td className="td"><RiskBadge level={r.expected_level} /></td>
                    <td className="td"><RiskBadge level={r.observed_level} /></td>
                    <td className="td">
                      <span className={`rounded-md px-2 py-0.5 text-xs font-bold ${r.passed ? "bg-emerald-600 text-white" : "bg-red-600 text-white"}`}>{r.passed ? "PASS" : "FAIL"}</span>
                    </td>
                    <td className="td text-slate-600">{r.explanation}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="card text-sm text-slate-700">
            <h2 className="mb-2 text-base font-semibold text-slate-900">Exercise-set counts</h2>
            <ul className="list-disc space-y-1 pl-5">
              <li>Expected labels: {s.expected_counts.LOW} LOW, {s.expected_counts.MEDIUM} MEDIUM, {s.expected_counts.HIGH} HIGH.</li>
              <li>Score matches: {s.score_matches}/{s.total}. Risk-level matches: {s.level_matches}/{s.total}.</li>
              <li>False alarm = expected LOW but observed MEDIUM/HIGH. Missed HIGH = expected HIGH but observed LOW/MEDIUM.</li>
              <li>HIGH-class precision: {s.high_precision ?? "n/a"}; recall: {s.high_recall ?? "n/a"} (computed on these 9 examples only).</li>
            </ul>
          </div>
          <InfoNote>{s.note} A tiny synthetic test set is not evidence of production-grade detection accuracy, and the rules were written with these examples in view.</InfoNote>
        </div>
      )}
    </div>
  );
}
