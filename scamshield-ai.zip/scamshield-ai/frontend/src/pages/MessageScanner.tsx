import { useEffect, useState } from "react";
import { Eraser, ScanSearch } from "lucide-react";
import { DemoSafetyNotice, ErrorNote, PageHeader } from "../components/Notices";
import { ResultView } from "../components/ResultView";
import { analyzeMessage } from "../services/api";
import type { AnalysisResult, MessageSample } from "../types";

const MAX_LEN = 5000;

interface Props {
  samples: MessageSample[];
  loaded: MessageSample | null;
  onAnalyzed: (result: AnalysisResult) => void;
}

export default function MessageScanner({ samples, loaded, onAnalyzed }: Props) {
  const [text, setText] = useState("");
  const [sampleId, setSampleId] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [runKey, setRunKey] = useState(0);

  // A sample sent from the Sample Lab replaces the current input.
  useEffect(() => {
    if (loaded) {
      setText(loaded.text);
      setSampleId(loaded.id);
      setResult(null);
      setError(null);
    }
  }, [loaded]);

  function chooseSample(id: string) {
    const sample = samples.find((s) => s.id === id);
    if (!sample) {
      setSampleId(null);
      return;
    }
    setText(sample.text);
    setSampleId(sample.id);
    setResult(null);
    setError(null);
  }

  function clearAll() {
    setText("");
    setSampleId(null);
    setResult(null);
    setError(null);
  }

  async function analyze() {
    setError(null);
    if (!text.trim()) {
      setError("Please paste a message to analyze.");
      return;
    }
    if (text.length > MAX_LEN) {
      setError(`The message is too long. Please keep it under ${MAX_LEN.toLocaleString()} characters.`);
      return;
    }
    setLoading(true);
    try {
      const r = await analyzeMessage(text, sampleId);
      setResult(r);
      setRunKey((k) => k + 1);
      onAnalyzed(r);
    } catch (e) {
      setResult(null);
      setError(e instanceof Error ? e.message : "Analysis failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <PageHeader title="Message Scanner" subtitle="Paste a suspicious SMS or email. Links are analysed as text only and are never opened." />
      <div className="grid gap-5 xl:grid-cols-2">
        <section className="card space-y-4" aria-labelledby="msg-input-heading">
          <h2 id="msg-input-heading" className="text-base font-semibold">Message to analyze</h2>
          <DemoSafetyNotice />
          <div>
            <label htmlFor="sample-select" className="mb-1 block text-sm font-medium text-slate-700">Load a synthetic sample (optional)</label>
            <select id="sample-select" className="input" value={sampleId ?? ""} onChange={(e) => chooseSample(e.target.value)}>
              <option value="">— Custom message —</option>
              {samples.map((s) => (
                <option key={s.id} value={s.id}>{s.id}: {s.text.slice(0, 50)}{s.text.length > 50 ? "…" : ""}</option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="msg-text" className="mb-1 block text-sm font-medium text-slate-700">Pasted message</label>
            <textarea
              id="msg-text"
              className="input min-h-[170px] resize-y"
              value={text}
              onChange={(e) => {
                setText(e.target.value);
                setSampleId(null);
              }}
              placeholder="Paste a synthetic or redacted message here…"
              aria-describedby="msg-count"
            />
            <p id="msg-count" className={`mt-1 text-xs ${text.length > MAX_LEN ? "text-red-700" : "text-slate-500"}`}>
              {text.length.toLocaleString()} / {MAX_LEN.toLocaleString()} characters
            </p>
          </div>
          {error && <ErrorNote>{error}</ErrorNote>}
          <div className="flex flex-wrap gap-2">
            <button type="button" className="btn-primary" onClick={analyze} disabled={loading}>
              <ScanSearch className="h-4 w-4" aria-hidden="true" /> {loading ? "Analyzing…" : "Analyze Message"}
            </button>
            <button type="button" className="btn-secondary" onClick={clearAll}>
              <Eraser className="h-4 w-4" aria-hidden="true" /> Clear input
            </button>
          </div>
        </section>

        <section className="card" aria-labelledby="msg-result-heading">
          <h2 id="msg-result-heading" className="mb-4 text-base font-semibold">Result</h2>
          {result ? (
            <ResultView key={runKey} result={result} />
          ) : (
            <p className="rounded-lg border border-dashed border-slate-300 p-6 text-center text-sm text-slate-500">
              No analysis yet. Paste a message or pick a sample, then press “Analyze Message”.
            </p>
          )}
        </section>
      </div>
    </div>
  );
}
