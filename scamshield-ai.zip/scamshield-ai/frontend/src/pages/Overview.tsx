import { ArrowRight, History, Trash2 } from "lucide-react";
import { InfoNote, PageHeader } from "../components/Notices";
import { LEVEL_STYLES, RiskBadge } from "../components/RiskBadge";
import type { HistoryItem, PageId, RiskLevel, SamplesResponse } from "../types";

interface Props {
  samples: SamplesResponse;
  history: HistoryItem[];
  onNavigate: (page: PageId) => void;
  onClearHistory: () => void;
}

export default function Overview({ samples, history, onNavigate, onClearHistory }: Props) {
  const all = [...samples.messages, ...samples.transactions];
  const counts: Record<RiskLevel, number> = { LOW: 0, MEDIUM: 0, HIGH: 0 };
  all.forEach((s) => (counts[s.expected_level] += 1));
  const max = Math.max(1, ...Object.values(counts));

  return (
    <div>
      <PageHeader title="Overview" subtitle="Pause. Check. Stay Safe. Explainable triage for suspicious messages and transactions." />

      <div className="mb-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
        {[
          ["Demo message samples", samples.messages.length],
          ["Demo transaction samples", samples.transactions.length],
          ["Total test examples", all.length],
        ].map(([k, v]) => (
          <div key={k} className="card !p-4">
            <p className="text-xs text-slate-500">{k}</p>
            <p className="text-3xl font-extrabold text-navy-900">{v}</p>
          </div>
        ))}
      </div>

      <div className="mb-5 flex flex-wrap gap-3">
        <button type="button" className="btn-primary" onClick={() => onNavigate("message")}>Open Message Scanner <ArrowRight className="h-4 w-4" aria-hidden="true" /></button>
        <button type="button" className="btn-primary" onClick={() => onNavigate("transaction")}>Open Transaction Checker <ArrowRight className="h-4 w-4" aria-hidden="true" /></button>
        <button type="button" className="btn-secondary" onClick={() => onNavigate("evaluation")}>View test results</button>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <section className="card" aria-labelledby="dist-heading">
          <h2 id="dist-heading" className="mb-3 text-base font-semibold">Risk levels of the supplied examples</h2>
          <ul className="space-y-3">
            {(["LOW", "MEDIUM", "HIGH"] as RiskLevel[]).map((lvl) => (
              <li key={lvl}>
                <div className="mb-1 flex items-center justify-between text-sm">
                  <RiskBadge level={lvl} />
                  <span className="font-semibold">{counts[lvl]} of {all.length}</span>
                </div>
                <div className="h-2 rounded-full bg-slate-200" aria-hidden="true">
                  <div className={`h-2 rounded-full ${LEVEL_STYLES[lvl].bar}`} style={{ width: `${(counts[lvl] / max) * 100}%` }} />
                </div>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-xs text-slate-500">Counts use the expected exercise labels of the synthetic examples.</p>
        </section>

        <section className="card" aria-labelledby="how-heading">
          <h2 id="how-heading" className="mb-3 text-base font-semibold">How scoring works</h2>
          <ul className="space-y-1 text-sm text-slate-700">
            <li><b>Message:</b> urgency +25, credential request +35, suspicious link +25, advance-fee +50 (each counted once).</li>
            <li><b>Transaction:</b> highest amount tier only (1.5× +10, 3× +30, 10× +50) plus new device +25.</li>
            <li><b>Bands:</b> LOW 0–24 · MEDIUM 25–49 · HIGH 50+. Score capped at 100.</li>
          </ul>
          <button type="button" className="mt-3 text-sm font-semibold text-sky-700 underline" onClick={() => onNavigate("about")}>Read the full methodology</button>
        </section>
      </div>

      <section className="card mt-5" aria-labelledby="recent-heading">
        <div className="mb-3 flex items-center justify-between">
          <h2 id="recent-heading" className="flex items-center gap-2 text-base font-semibold"><History className="h-4 w-4" aria-hidden="true" /> Recent analyses (this session)</h2>
          <button type="button" className="btn-secondary" onClick={onClearHistory} disabled={history.length === 0}><Trash2 className="h-4 w-4" aria-hidden="true" /> Clear</button>
        </div>
        {history.length === 0 ? (
          <p className="rounded-lg border border-dashed border-slate-300 p-5 text-center text-sm text-slate-500">No analyses yet. Run one from the scanners or the Sample Lab. Only the score and level are kept, never the text.</p>
        ) : (
          <ul className="divide-y divide-slate-100">
            {history.map((h) => (
              <li key={h.id} className="flex flex-wrap items-center justify-between gap-2 py-2 text-sm">
                <span className="capitalize">{h.category}{h.sampleId ? ` · ${h.sampleId}` : " · custom"}</span>
                <span className="flex items-center gap-3"><RiskBadge level={h.level} score={h.score} /><span className="text-xs text-slate-500">{h.at}</span></span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <div className="mt-5"><InfoNote>These demo statistics come from 9 synthetic examples and do not establish real-world accuracy or impact.</InfoNote></div>
    </div>
  );
}
