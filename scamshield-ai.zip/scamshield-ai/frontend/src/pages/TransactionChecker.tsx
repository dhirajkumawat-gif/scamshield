import { useEffect, useState } from "react";
import { Calculator, RotateCcw } from "lucide-react";
import { DemoSafetyNotice, ErrorNote, InfoNote, PageHeader } from "../components/Notices";
import { ResultView } from "../components/ResultView";
import { analyzeTransaction } from "../services/api";
import type { AnalysisResult, TransactionSample } from "../types";

interface Props {
  samples: TransactionSample[];
  loaded: TransactionSample | null;
  onAnalyzed: (result: AnalysisResult) => void;
}

export default function TransactionChecker({ samples, loaded, onAnalyzed }: Props) {
  const [amount, setAmount] = useState("");
  const [baseline, setBaseline] = useState("");
  const [newDevice, setNewDevice] = useState(false);
  const [sampleId, setSampleId] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [runKey, setRunKey] = useState(0);

  function fill(s: TransactionSample) {
    setAmount(String(s.amount));
    setBaseline(String(s.baseline));
    setNewDevice(s.new_device);
    setSampleId(s.id);
    setResult(null);
    setError(null);
  }

  useEffect(() => {
    if (loaded) fill(loaded);
  }, [loaded]);

  function reset() {
    setAmount("");
    setBaseline("");
    setNewDevice(false);
    setSampleId(null);
    setResult(null);
    setError(null);
  }

  async function analyze() {
    setError(null);
    const a = Number(amount);
    const b = Number(baseline);
    if (amount.trim() === "" || baseline.trim() === "" || !Number.isFinite(a) || !Number.isFinite(b)) {
      setError("Please enter valid numbers for the amount and the baseline.");
      return;
    }
    if (a < 0) {
      setError("Transaction amount cannot be negative.");
      return;
    }
    if (b <= 0) {
      setError("Baseline must be greater than zero.");
      return;
    }
    setLoading(true);
    try {
      const r = await analyzeTransaction(a, b, newDevice, sampleId);
      setResult(r);
      setRunKey((k) => k + 1);
      onAnalyzed(r);
    } catch (e) {
      setResult(null);
      setError(e instanceof Error ? e.message : "Analysis failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <PageHeader title="Transaction Risk Checker" subtitle="Compare a synthetic transaction with a fictional usual baseline (INR)." />
      <div className="grid gap-5 xl:grid-cols-2">
        <section className="card space-y-4" aria-labelledby="tx-input-heading">
          <h2 id="tx-input-heading" className="text-base font-semibold">Transaction details</h2>
          <DemoSafetyNotice />
          <InfoNote>This form never asks for account numbers, card numbers, OTPs, PINs or passwords. Use fictional values only.</InfoNote>
          <div>
            <label htmlFor="tx-sample" className="mb-1 block text-sm font-medium text-slate-700">Load a synthetic sample (optional)</label>
            <select
              id="tx-sample"
              className="input"
              value={sampleId ?? ""}
              onChange={(e) => {
                const s = samples.find((x) => x.id === e.target.value);
                if (s) fill(s);
                else setSampleId(null);
              }}
            >
              <option value="">— Custom values —</option>
              {samples.map((s) => (
                <option key={s.id} value={s.id}>{s.id}: ₹{s.amount.toLocaleString("en-IN")} vs ₹{s.baseline.toLocaleString("en-IN")}{s.new_device ? ", new device" : ""}</option>
              ))}
            </select>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="tx-amount" className="mb-1 block text-sm font-medium text-slate-700">Transaction amount (INR)</label>
              <input id="tx-amount" type="number" inputMode="decimal" min="0" step="any" className="input" value={amount}
                onChange={(e) => { setAmount(e.target.value); setSampleId(null); }} placeholder="e.g. 3000" />
            </div>
            <div>
              <label htmlFor="tx-baseline" className="mb-1 block text-sm font-medium text-slate-700">Usual baseline (INR, fictional)</label>
              <input id="tx-baseline" type="number" inputMode="decimal" min="0" step="any" className="input" value={baseline}
                onChange={(e) => { setBaseline(e.target.value); setSampleId(null); }} placeholder="e.g. 700" />
            </div>
          </div>
          <label className="flex items-center gap-2 text-sm font-medium text-slate-700">
            <input type="checkbox" className="h-4 w-4 rounded border-slate-300" checked={newDevice}
              onChange={(e) => { setNewDevice(e.target.checked); setSampleId(null); }} />
            Transaction came from a new device
          </label>
          {error && <ErrorNote>{error}</ErrorNote>}
          <div className="flex flex-wrap gap-2">
            <button type="button" className="btn-primary" onClick={analyze} disabled={loading}>
              <Calculator className="h-4 w-4" aria-hidden="true" /> {loading ? "Analyzing…" : "Analyze Transaction"}
            </button>
            <button type="button" className="btn-secondary" onClick={reset}>
              <RotateCcw className="h-4 w-4" aria-hidden="true" /> Reset
            </button>
          </div>
        </section>

        <section className="card" aria-labelledby="tx-result-heading">
          <h2 id="tx-result-heading" className="mb-4 text-base font-semibold">Result</h2>
          {result ? (
            <ResultView key={runKey} result={result} />
          ) : (
            <p className="rounded-lg border border-dashed border-slate-300 p-6 text-center text-sm text-slate-500">
              No analysis yet. Enter values or pick a sample, then press “Analyze Transaction”.
            </p>
          )}
        </section>
      </div>
    </div>
  );
}
