import { useCallback, useEffect, useState } from "react";
import { RefreshCw, Trash2 } from "lucide-react";
import { ErrorNote, InfoNote, PageHeader } from "../components/Notices";
import { RiskBadge } from "../components/RiskBadge";
import { clearFeedback, getFeedback } from "../services/api";
import type { FeedbackRecord } from "../types";

export default function FeedbackPage() {
  const [records, setRecords] = useState<FeedbackRecord[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    try {
      setRecords((await getFeedback()).records);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not load feedback.");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function clearAll() {
    try {
      const { cleared } = await clearFeedback();
      setRecords([]);
      setStatus(`Cleared ${cleared} feedback record${cleared === 1 ? "" : "s"}.`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not clear feedback.");
    }
  }

  return (
    <div>
      <PageHeader title="Feedback" subtitle="Useful / Not useful choices recorded from analysis results." />
      <div className="mb-4"><InfoNote>Feedback is kept in the backend server’s memory only. It disappears when the server restarts. Original messages and transaction inputs are never stored with feedback.</InfoNote></div>
      <div className="mb-4 flex gap-2">
        <button type="button" className="btn-secondary" onClick={() => void load()}><RefreshCw className="h-4 w-4" aria-hidden="true" /> Refresh</button>
        <button type="button" className="btn-secondary" onClick={() => void clearAll()} disabled={records.length === 0}><Trash2 className="h-4 w-4" aria-hidden="true" /> Clear demo feedback</button>
      </div>
      {status && <p role="status" className="mb-3 text-sm text-emerald-700">{status}</p>}
      {error && <ErrorNote>{error}</ErrorNote>}
      {records.length === 0 ? (
        <p className="card text-center text-sm text-slate-500">No feedback recorded yet. Analyze a message or transaction and press “Useful” or “Not useful”.</p>
      ) : (
        <div className="card overflow-x-auto !p-0">
          <table className="min-w-full divide-y divide-slate-200">
            <caption className="sr-only">Recorded feedback</caption>
            <thead className="bg-slate-50">
              <tr>{["ID", "Sample", "Category", "Choice", "Result", "Comment", "Time (UTC)"].map((h) => <th key={h} scope="col" className="th">{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {records.map((r) => (
                <tr key={r.id}>
                  <td className="td font-bold">{r.id}</td>
                  <td className="td">{r.sample_id ?? "custom"}</td>
                  <td className="td capitalize">{r.category}</td>
                  <td className="td">{r.choice === "useful" ? "Useful" : "Not useful"}</td>
                  <td className="td">{r.level && r.score !== null ? <RiskBadge level={r.level} score={r.score} /> : "—"}</td>
                  <td className="td">{r.comment ?? "—"}</td>
                  <td className="td text-slate-500">{r.created_at.replace("T", " ").slice(0, 19)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
