import { InfoNote, PageHeader } from "../components/Notices";

function Table({ head, rows }: { head: string[]; rows: string[][] }) {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-slate-200 text-sm">
        <thead className="bg-slate-50"><tr>{head.map((h) => <th key={h} scope="col" className="th">{h}</th>)}</tr></thead>
        <tbody className="divide-y divide-slate-100">
          {rows.map((r) => <tr key={r[0]}>{r.map((c, i) => <td key={i} className="td">{c}</td>)}</tr>)}
        </tbody>
      </table>
    </div>
  );
}

export default function About() {
  return (
    <div className="space-y-5">
      <PageHeader title="About, Methodology & Limitations" subtitle="ScamShield AI · Sobhasaria Hackfest 2026 · Challenge H05 · Technology partner: JH-NEXIS" />

      <section className="card">
        <h2 className="mb-2 text-base font-semibold">What this is</h2>
        <p className="text-sm text-slate-700">A defensive, rule-based prototype that analyses pasted messages and synthetic transactions, explains every risk signal, and suggests cautious next steps. It supports human decisions; it never claims that a person, message or transaction is fraudulent.</p>
      </section>

      <section className="card space-y-3">
        <h2 className="text-base font-semibold">Message scoring (each signal counts once)</h2>
        <Table head={["Signal", "Points", "Notes"]} rows={[
          ["Urgency or threat", "+25", "Pressure wording such as urgent, act now, immediately, blocked or frozen."],
          ["Request for credentials", "+35", "A request to share/send/enter an OTP, PIN, password or card detail. Merely mentioning a code, or saying “do not share”, scores 0."],
          ["Suspicious link pattern", "+25", "Look-alike words in the domain, raw IP, shortener, or a link beside verification/account-threat wording. Links are never opened."],
          ["Advance-fee or prize", "+50", "Prize/benefit wording together with a request to pay a fee first."],
        ]} />
      </section>

      <section className="card space-y-3">
        <h2 className="text-base font-semibold">Transaction scoring</h2>
        <Table head={["Factor", "Points", "Notes"]} rows={[
          ["Amount ≥ 1.5× baseline", "+10", "Only the highest amount tier applies."],
          ["Amount ≥ 3× baseline", "+30", "Replaces the 1.5× tier."],
          ["Amount ≥ 10× baseline", "+50", "Replaces the lower tiers."],
          ["New device", "+25", "Added to the amount tier."],
        ]} />
        <p className="text-sm text-slate-700">Classification uses the unrounded ratio. Risk bands: LOW 0–24, MEDIUM 25–49, HIGH 50 and above. Scores are capped at 100. Scoring is deterministic: the same input always gives the same result.</p>
      </section>

      <section className="card">
        <h2 className="mb-2 text-base font-semibold">Impact statement</h2>
        <ul className="list-disc space-y-1 pl-5 text-sm text-slate-700">
          <li><b>Measured:</b> results on the nine supplied synthetic examples (see Evaluation page).</li>
          <li><b>Possible future benefit (not measured):</b> helping users pause and verify before acting on pressure messages.</li>
          <li><b>Not measured:</b> any reduction in real fraud, financial loss or victimisation; real-world precision or recall.</li>
        </ul>
      </section>

      <section className="card">
        <h2 className="mb-2 text-base font-semibold">Privacy & safety</h2>
        <ul className="list-disc space-y-1 pl-5 text-sm text-slate-700">
          <li>No external APIs or third-party AI: everything runs locally and works offline.</li>
          <li>Message text is analysed in memory and is not stored, logged or returned. Feedback and session history never contain the message.</li>
          <li>Feedback is stored in server memory only and is lost on restart.</li>
          <li>Do not enter real OTPs, passwords, card numbers or banking details.</li>
        </ul>
      </section>

      <section className="card">
        <h2 className="mb-2 text-base font-semibold">Known limitations</h2>
        <ul className="list-disc space-y-1 pl-5 text-sm text-slate-700">
          <li>Rules are English-only pattern matches and can be evaded by rewording, misspelling or other languages.</li>
          <li>Legitimate messages with a verification link may be flagged; scam messages without these patterns will score LOW.</li>
          <li>The rules were designed against the nine supplied examples, so a perfect score on them proves little.</li>
          <li>No bank integration: the tool cannot block, reverse or investigate any transaction.</li>
        </ul>
      </section>

      <InfoNote>A risk flag is not proof of fraud. This is a prototype for education and demonstration.</InfoNote>
    </div>
  );
}
