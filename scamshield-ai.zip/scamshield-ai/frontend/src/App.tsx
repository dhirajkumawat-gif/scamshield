import { useCallback, useEffect, useState } from "react";
import {
  ArrowLeftRight,
  ClipboardCheck,
  FlaskConical,
  Info,
  LayoutDashboard,
  Menu,
  MessageSquareWarning,
  ShieldCheck,
  ThumbsUp,
  X,
} from "lucide-react";
import type { ComponentType } from "react";
import { DEMO_SAFETY_TEXT, ErrorNote } from "./components/Notices";
import About from "./pages/About";
import Evaluation from "./pages/Evaluation";
import FeedbackPage from "./pages/FeedbackPage";
import MessageScanner from "./pages/MessageScanner";
import Overview from "./pages/Overview";
import SampleLab from "./pages/SampleLab";
import TransactionChecker from "./pages/TransactionChecker";
import { getSamples } from "./services/api";
import type { AnalysisResult, HistoryItem, MessageSample, PageId, SamplesResponse, TransactionSample } from "./types";

const NAV: { id: PageId; label: string; icon: ComponentType<{ className?: string }> }[] = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "message", label: "Message Scanner", icon: MessageSquareWarning },
  { id: "transaction", label: "Transaction Checker", icon: ArrowLeftRight },
  { id: "lab", label: "Sample Lab", icon: FlaskConical },
  { id: "evaluation", label: "Evaluation", icon: ClipboardCheck },
  { id: "feedback", label: "Feedback", icon: ThumbsUp },
  { id: "about", label: "About & Limits", icon: Info },
];

export default function App() {
  const [page, setPage] = useState<PageId>("overview");
  const [menuOpen, setMenuOpen] = useState(false);
  const [samples, setSamples] = useState<SamplesResponse | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [loadedMessage, setLoadedMessage] = useState<MessageSample | null>(null);
  const [loadedTx, setLoadedTx] = useState<TransactionSample | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);

  const loadSamples = useCallback(async () => {
    setLoadError(null);
    try {
      setSamples(await getSamples());
    } catch (e) {
      setLoadError(e instanceof Error ? e.message : "Could not load samples.");
    }
  }, []);

  useEffect(() => {
    void loadSamples();
  }, [loadSamples]);

  // Session history keeps only category, sample id, score and level. Never the text.
  const addHistory = useCallback((r: AnalysisResult) => {
    setHistory((h) =>
      [{ id: Date.now() + Math.random(), category: r.category, sampleId: r.sample_id ?? null, score: r.score, level: r.level, at: new Date().toLocaleTimeString() }, ...h].slice(0, 10),
    );
  }, []);

  function go(p: PageId) {
    setPage(p);
    setMenuOpen(false);
    window.scrollTo({ top: 0 });
  }

  function renderPage() {
    if (loadError) {
      return (
        <div className="space-y-3">
          <ErrorNote>{loadError}</ErrorNote>
          <button type="button" className="btn-primary" onClick={() => void loadSamples()}>Retry</button>
        </div>
      );
    }
    if (!samples) return <p role="status" className="text-sm text-slate-500">Loading…</p>;
    switch (page) {
      case "overview":
        return <Overview samples={samples} history={history} onNavigate={go} onClearHistory={() => setHistory([])} />;
      case "message":
        return <MessageScanner samples={samples.messages} loaded={loadedMessage} onAnalyzed={addHistory} />;
      case "transaction":
        return <TransactionChecker samples={samples.transactions} loaded={loadedTx} onAnalyzed={addHistory} />;
      case "lab":
        return (
          <SampleLab
            messages={samples.messages}
            transactions={samples.transactions}
            onAnalyzed={addHistory}
            onLoadMessage={(s) => { setLoadedMessage({ ...s }); go("message"); }}
            onLoadTransaction={(s) => { setLoadedTx({ ...s }); go("transaction"); }}
          />
        );
      case "evaluation":
        return <Evaluation />;
      case "feedback":
        return <FeedbackPage />;
      case "about":
        return <About />;
    }
  }

  const nav = (
    <nav aria-label="Main navigation" className="space-y-1">
      {NAV.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          type="button"
          onClick={() => go(id)}
          aria-current={page === id ? "page" : undefined}
          className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left text-sm font-medium transition ${
            page === id ? "bg-white/15 text-white" : "text-slate-300 hover:bg-white/10 hover:text-white"
          }`}
        >
          <Icon className="h-4 w-4" aria-hidden="true" /> {label}
        </button>
      ))}
    </nav>
  );

  const brand = (
    <div className="flex items-center gap-3">
      <div className="rounded-xl bg-sky-500/20 p-2"><ShieldCheck className="h-6 w-6 text-sky-300" aria-hidden="true" /></div>
      <div>
        <p className="text-base font-bold leading-tight text-white">ScamShield AI</p>
        <p className="text-[11px] text-slate-400">H05 · Pause. Check. Stay Safe.</p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen lg:flex">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-white focus:p-2">Skip to content</a>

      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col justify-between bg-navy-900 p-4 lg:flex lg:sticky lg:top-0 lg:h-screen">
        <div className="space-y-6">{brand}{nav}</div>
        <p className="text-[11px] leading-snug text-slate-400">Prototype · Sobhasaria Hackfest 2026<br />Technology partner: JH-NEXIS</p>
      </aside>

      {/* Mobile / tablet top bar */}
      <header className="bg-navy-900 p-3 lg:hidden">
        <div className="flex items-center justify-between">
          {brand}
          <button type="button" className="rounded-lg p-2 text-white hover:bg-white/10" aria-expanded={menuOpen} aria-label={menuOpen ? "Close menu" : "Open menu"} onClick={() => setMenuOpen((o) => !o)}>
            {menuOpen ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
          </button>
        </div>
        {menuOpen && <div className="mt-3">{nav}</div>}
      </header>

      <div className="min-w-0 flex-1">
        <div role="note" className="border-b border-amber-300 bg-amber-100 px-4 py-2 text-xs text-amber-950 sm:text-sm">
          <b>Prototype · synthetic data only.</b> {DEMO_SAFETY_TEXT}
        </div>
        <main id="main" className="mx-auto max-w-6xl p-4 sm:p-6">{renderPage()}</main>
      </div>
    </div>
  );
}
