import type {
  AnalysisResult,
  Category,
  Choice,
  EvaluationResponse,
  FeedbackRecord,
  RiskLevel,
  SamplesResponse,
} from "../types";

const BASE = "/api";

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${BASE}${path}`, {
      headers: { "Content-Type": "application/json" },
      ...init,
    });
  } catch {
    throw new Error("Cannot reach the ScamShield backend. Make sure it is running on port 8000.");
  }
  if (!res.ok) {
    let message = `Request failed (${res.status}).`;
    try {
      const body = (await res.json()) as { detail?: unknown };
      if (typeof body.detail === "string") message = body.detail;
    } catch {
      /* keep the generic message */
    }
    throw new Error(message);
  }
  return (await res.json()) as T;
}

export const getSamples = () => request<SamplesResponse>("/samples");

export const analyzeMessage = (message: string, sampleId?: string | null) =>
  request<AnalysisResult>("/analyze/message", {
    method: "POST",
    body: JSON.stringify({ message, sample_id: sampleId ?? null }),
  });

export const analyzeTransaction = (amount: number, baseline: number, newDevice: boolean, sampleId?: string | null) =>
  request<AnalysisResult>("/analyze/transaction", {
    method: "POST",
    body: JSON.stringify({ amount, baseline, new_device: newDevice, sample_id: sampleId ?? null }),
  });

export const getEvaluation = () => request<EvaluationResponse>("/evaluation");

export interface FeedbackPayload {
  category: Category;
  choice: Choice;
  sample_id?: string | null;
  comment?: string | null;
  score?: number | null;
  level?: RiskLevel | null;
}

export const submitFeedback = (payload: FeedbackPayload) =>
  request<FeedbackRecord>("/feedback", { method: "POST", body: JSON.stringify(payload) });

export const getFeedback = () => request<{ records: FeedbackRecord[]; storage: string }>("/feedback");

export const clearFeedback = () => request<{ cleared: number }>("/feedback", { method: "DELETE" });
