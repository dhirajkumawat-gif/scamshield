import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

// In development the frontend (5173) proxies /api to the FastAPI backend (8000).
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { "/api": "http://127.0.0.1:8000" },
  },
  test: {
    environment: "jsdom",
  },
});
